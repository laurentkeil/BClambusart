/* script unavailable:  affiliate traffic throttled */
